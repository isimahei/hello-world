import botocore
import boto3
import json
import argparse
import os
from argparse import RawTextHelpFormatter
from .gdQuestsApi import GameDayQuestsApiClient
from .manage_qdk import undeploy_stack
import multiprocessing

try:
    PROFILE = os.environ['AWS_GAMEDAY_PROFILE']
    boto3_session = boto3.Session(profile_name=PROFILE)
except Exception as e:
    boto3_session = boto3.Session()

cfn_client = boto3_session.client("cloudformation")
ddb_client = boto3_session.client('dynamodb')
QUEST_TABLE = "gdQuestsApi-Quests"
QUEST_STATES_TABLE = "gdQuestsApi-QuestStates"
OUTPUT_TABLE = "gdQuestsApi-Outputs"
INPUT_TABLE = "gdQuestsApi-Inputs"
MOCK_TEAMS_TABLE = "gdQuestsApi-MockTeams"


def reset_quest_table(quest_id):
    # reset quest-central-status to "DISABLED"
    # reset quest-enabled to false
    try:
        response = ddb_client.update_item(
            TableName=QUEST_TABLE,
            Key={
                "quest-id": {'S': quest_id}
            },
            UpdateExpression=
            "set #qcs = :qcs, #qe = :qe"
            ,
            ExpressionAttributeValues={
                ":qcs": {'S': "DISABLED"},
                ":qe": {'BOOL': False}
            },
            ExpressionAttributeNames={
                "#qe": "quest-enabled",
                "#qcs": "quest-central-status"
            },
            ReturnValues="UPDATED_NEW"
        )
        print(response)
    except botocore.exceptions.ClientError as err:
        print("ERROR in " + QUEST_TABLE + ": ", err)
    return


def delete_quest_states(quest_id, team_id):
    try:
        team_items_response = ddb_client.scan(
            TableName=MOCK_TEAMS_TABLE
        )
        # print(json.dumps(response, indent=4))
        if team_id == None:
            for team in team_items_response['Items']:
                response = ddb_client.delete_item(
                    TableName=QUEST_STATES_TABLE,
                    Key={
                        "team-id": {'S': team["team-id"]['S']},
                        "quest-id": {'S': quest_id}
                    }
                )
                print(json.dumps(response, indent=4))
        else:
            response = ddb_client.delete_item(
                TableName=QUEST_STATES_TABLE,
                Key={
                    "team-id": {'S': team_id},
                    "quest-id": {'S': quest_id}
                }
            )
            print(json.dumps(response, indent=4))

    except botocore.exceptions.ClientError as err:
        print("ERROR in " + QUEST_STATES_TABLE + ": ", err)
    return


def reset_quest_states(quest_id, team_id):
    # ("changing quests states status to AVAILABLE")
    try:
        team_items_response = ddb_client.scan(
            TableName=MOCK_TEAMS_TABLE
        )
        if team_id is None:
            for team in team_items_response['Items']:
                response = ddb_client.update_item(
                    TableName=QUEST_STATES_TABLE,
                    Key={
                        "team-id": {'S': team['team-id']['S']},
                        "quest-id": {'S': quest_id}
                    },
                    UpdateExpression=
                    "set #qs = :qs, \
                    #qct = :qct, \
                    #qst = :qst"
                    ,
                    ExpressionAttributeValues={
                        ":qs": {'S': "AVAILABLE"},
                        ":qct": {'N': "0"},
                        ":qst": {'N': "0"}
                    },
                    ExpressionAttributeNames={
                        "#qs": "quest-state",
                        "#qct": "quest-complete-time",
                        "#qst": "quest-start-time"
                    }
                )
                print(response)
        else:
            response = ddb_client.update_item(
                TableName=QUEST_STATES_TABLE,
                Key={
                    "team-id": {'S': team_id},
                    "quest-id": {'S': quest_id}
                },
                UpdateExpression=
                "set #qs = :qs, \
                #qct = :qct, \
                #qst = :qst"
                ,
                ExpressionAttributeValues={
                    ":qs": {'S': "AVAILABLE"},
                    ":qct": {'N': "0"},
                    ":qst": {'N': "0"}
                },
                ExpressionAttributeNames={
                    "#qs": "quest-state",
                    "#qct": "quest-complete-time",
                    "#qst": "quest-start-time"
                }
            )
            print(response)

    except botocore.exceptions.ClientError as err:
        print("ERROR in " + QUEST_STATES_TABLE + ": ", err)
    return


def delete_outputs(quest_id, team_id):
    try:
        output_table_response = ddb_client.scan(
            TableName=OUTPUT_TABLE
        )
        # print(json.dumps(response, indent=4))
        if team_id is None:
            for output in output_table_response['Items']:
                response = ddb_client.delete_item(
                    TableName=OUTPUT_TABLE,
                    Key={
                        "team-id": {'S': output["team-id"]['S']},
                        "key": {'S': output["key"]['S']}
                    }
                )
                print(json.dumps(response, indent=4))
        else:
            for output in output_table_response['Items']:
                if output["team-id"]['S'] == team_id:
                    response = ddb_client.delete_item(
                        TableName=OUTPUT_TABLE,
                        Key={
                            "team-id": {'S': team_id},
                            "key": {'S': output["key"]['S']}
                        }
                    )
                    print(json.dumps(response, indent=4))
    except botocore.exceptions.ClientError as err:
        print("ERROR in " + OUTPUT_TABLE + ": ", err, )
    return


def delete_inputs(quest_id, team_id):
    try:
        input_table_response = ddb_client.scan(
            TableName=INPUT_TABLE
        )
        # print(json.dumps(response, indent=4))
        if team_id == None:
            for input in input_table_response['Items']:
                response = ddb_client.delete_item(
                    TableName=INPUT_TABLE,
                    Key={
                        "team-id": {'S': input["team-id"]['S']},
                        "key": {'S': input["key"]['S']}
                    }
                )
                print(json.dumps(response, indent=4))
        else:
            for input in input_table_response['Items']:
                if team_id == input["team-id"]['S']:
                    response = ddb_client.delete_item(
                        TableName=INPUT_TABLE,
                        Key={
                            "team-id": {'S': team_id},
                            "key": {'S': input["key"]['S']}
                        }
                    )
                    print(json.dumps(response, indent=4))
    except botocore.exceptions.ClientError as err:
        print("ERROR in " + INPUT_TABLE + ": ", err)
    return


def undeploy_quests(quest_id, quests_client, wait_tolerance=30):
    quests = quests_client.get_all_quests()
    possible_stacks = []
    possible_stacks.append(f"gdQuests-{quest_id}-Enable")
    possible_stacks.append(f"gdQuests-{quest_id}-Central")
    possible_stacks.append(f"gdQuests-{quest_id}-Activate")
    cfn_response = cfn_client.describe_stacks()
    stacks_to_delete = []
    for stack in cfn_response['Stacks']:
        if stack['StackName'] in possible_stacks:
            stacks_to_delete.append((stack['StackName'], wait_tolerance))

    print(f"{len(stacks_to_delete)} Quest stacks found to delete, launching deleter pool")
    pool = multiprocessing.Pool(5)
    pool.starmap(undeploy_stack, stacks_to_delete)
    pool.close()
    pool.join()
    print("Deletes complete")

def quest_hard_reset(quest_id, team_id):
    reset_quest_table(quest_id)
    delete_quest_states(quest_id, team_id)
    delete_inputs(quest_id, team_id)
    delete_outputs(quest_id, team_id)

    quests_client = None
    try:
        quests_client = GameDayQuestsApiClient()
    except Exception as e:
        print(f"Unable to create GameDay Quests API Client due to error: {e}. Skipping Quest deletion attempt.")
    if quests_client is not None:
        # Undeploy Quests first to avoid dependencies or race conditions for dependent IAM roles
        print("Undeploying existing Quests and QDK")
        undeploy_quests(quest_id, quests_client)
    
    return


def reset_quest(quest_id, team_id):
    # resets ddb tables to prior to gdQuestsApi-postQuestStart
    reset_quest_states(quest_id, team_id)
    delete_outputs(quest_id, team_id)
    delete_inputs(quest_id, team_id)
    return


def main(argv=None):
    parser = argparse.ArgumentParser(description="""
            Reset the DyanmoDB Tables to original state. The process flow is to set the environment
            to a suitable state that allows redeployment and testing.

            This helper script will interact with the default AWS profile 
            configured in your environment.
        """, formatter_class=RawTextHelpFormatter)
    parser.add_argument(
        "--reset",
        help="HARD resets the Quest Environment to allow you to redeploy your Quest's " +
             "CloudFormation Templates with enable-quest.py" +
             "INIT resets the Quest Environment to prior to starting the Quest." +
             "Both commands will delete contents in the Outputs and Inputs Table",
        choices=["HARD", "INIT"],
        required=True
    )
    parser.add_argument(
        "--quest-id", help="Quest ID to reset in your QDK environment",
        required=True
    )

    parser.add_argument(
        "--team-id",
        help="Select a Team ID to reset tables for a specific team" +
             "If Team ID is not supplied all Team states will be reset. " +
             "Team IDs are dependent on your QDK environment, however the " +
             "default placeholder Team IDs deployed to the " +
             "gdQuestsApi-MockTeams DynamoDb table is: " +
             "24eec976eca648eab61514b241032041"
    )

    parser.add_argument(
        "--wait-tolerance",
        help="Minutes to wait for deployment actions to occur",
        type=int,
        default=5)

    params = vars(parser.parse_args(argv))

    quest_id = params['quest_id']
    team_id = params['team_id']
    reset_option = params['reset']
    wait_tolerance = params.get('wait_tolerance')

    # Assumes quest_id is not None due to argparse requirements. Error will be
    # passed through from the Lambda side if this assumption is false (e.g.
    # an unforseen external caller)

    print(params)

    ddb_response = ddb_client.get_item(
        TableName='gdQuestsApi-Quests',
        Key={
            'quest-id': {'S': quest_id}
        }
    )
    quest_data = ddb_response.get('Item')

    if quest_data is None:
        print('Quest does not exist in gdQuestsApi-Quests table. Check your ' +
              'dev-quest-data.json file. You may need to redeploy the QDK.')
        return

    if reset_option == "HARD":
        quest_hard_reset(quest_id, team_id)
    elif reset_option == "INIT":
        reset_quest(quest_id, team_id)

    return


if __name__ == "__main__":
    main()
