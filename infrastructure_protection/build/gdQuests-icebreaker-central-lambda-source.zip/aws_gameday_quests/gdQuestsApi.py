import boto3
import requests
import time
import os

try:
    PROFILE = os.environ['AWS_GAMEDAY_PROFILE']
    boto3_session = boto3.Session(profile_name=PROFILE)
except Exception as e:
    PROFILE = 'default'
    boto3_session = boto3.Session()


def get_response(url, headers, method):
    print(f"Calling get_response(url={url}, headers={headers}, method={method}")
    for x in range(0, 5):
        if x > 0:
            print("Waiting " + str(2 ** x) + " seconds before attempting retry " + str(x) + "...")
            time.sleep(2 ** x)
        try:
            r = requests.get(url, headers=headers, timeout=5)
            print(r)
            return r
        except Exception as e:
            print(f"Error with {str(method)} request: {str(e)}")
    return None


def post_response(url, headers, payload, method):
    print(f"Calling post_response(url={url}, headers={headers}, payload={payload}, method={method}")
    for x in range(0, 5):
        if x > 0:
            print("Waiting " + str(2 ** x) + " seconds before attempting retry " + str(x) + "...")
            time.sleep(2 ** x)
        try:
            r = requests.post(url, json=payload, headers=headers, timeout=5)
            print(r)
            return r
        except Exception as e:
            print(f"Error with {str(method)} request: {str(e)}")
    return None


def delete_response(url, headers, method):
    print(f"Calling delete_response(url={url}, headers={headers}, method={method}")
    for x in range(0, 5):
        if x > 0:
            print("Waiting " + str(2 ** x) + " seconds before attempting retry " + str(x) + "...")
            time.sleep(2 ** x)
        try:
            r = requests.delete(url, headers=headers, timeout=5)
            print(r)
            return r
        except Exception as e:
            print(f"Error with {str(method)} request: {str(e)}")
    return None


def patch_response(url, headers, payload, method):
    print(f"Calling patch_response(url={url}, headers={headers}, payload={payload}, method={method}")
    for x in range(0, 5):
        if x > 0:
            print("Waiting " + str(2 ** x) + " seconds before attempting retry " + str(x) + "...")
            time.sleep(2 ** x)
        try:
            r = requests.patch(url, payload, headers=headers, timeout=5)
            return r
        except Exception as e:
            print(f"Error with {str(method)} request: {str(e)}")
    return None


class GameDayQuestsApiClient:

    def __init__(self, api_base=None, api_token=None):
        if api_base is None or api_token is None:
            secrets_client = boto3_session.client("secretsmanager")
            ssm_client = boto3_session.client("ssm")
            if api_base is None:
                api_endpoint_response = ssm_client.get_parameter(Name="gdQuests-api-baseurl")
                api_base = api_endpoint_response['Parameter']['Value']
            if api_token is None:
                api_key_secret_response = secrets_client.get_secret_value(SecretId='QuestsApiToken')
                api_token = api_key_secret_response['SecretString']

        self.api_base = api_base
        self.api_token = api_token
        self.sts_client = boto3_session.client('sts')

    def assume_team_ops_role(self, team_id, duration=30 * 60):
        """
        Assume the management/ops (cross-account in live events) role into the team account
        :returns: boto3 session for the given team's OpsRole
        """
        team = self.get_team(team_id)
        assume_response = self.sts_client.assume_role(
            RoleArn=team['ops-role-arn'],
            RoleSessionName='gdQuests',
            DurationSeconds=duration,
        )
        cross_account_session = boto3.Session(
            aws_access_key_id=assume_response['Credentials']['AccessKeyId'],
            aws_secret_access_key=assume_response['Credentials']['SecretAccessKey'],
            aws_session_token=assume_response['Credentials']['SessionToken']
        )
        return cross_account_session

    def get_event_status(self):
        """
        :returns: the status of the overall this event exists within
        Valid statuses:
        CREATED - The event has been created in the encompassing platform but is not yet initializing
        INITIALIZING - Internal components of the overall event are provisioning
        READY - The event is ready to be started by the operator
        IN_PROGRESS - The event has been started by the operator and is running
        STOPPED - The operator has stopped the event and it is awaiting termination or being re-started
        TERMINATED - The event has been terminated
        Sample Response:
        {
            "status": "IN_PROGRESS"
        }
        """
        url = f"{self.api_base}/event/status"
        r = get_response(url, self._get_headers(), GameDayQuestsApiClient.get_event_status)
        return r.json()

    def post_image(self, team_id, quest_id, key, label, value, dashboard_index, description=""):
        """
        :param team_id: The team-id for the team for which you're creating the image interaction for
        :param quest_id: The quest-id that the image interaction relates to
        :param key: The internal identifier for the image interaction
        :param label: The label that applies to your image - usually representing a heading that applies to
                      your image content
        :param value: The HTTPS URL pointing to the image that you want displayed. If the $QUEST_ROOT prefix is 
                      supplied here, the image will be loaded from the root of the S3 bucket used to contain all 
                      assets for the specified quest (this is the preferred method for referencing images)
        :param dashboard_index: An index that allows you to set a display order for input fields. Fields with
                                lower order values are displayed above fields with higher order values. This
                                value must be an integer
        :param description: (Optional) Additional descriptive text that can appear as the alternate text for the
                            image
        """
        url = f"{self.api_base}/images/{team_id}/{quest_id}/{key}"
        payload = {
            "label": label,
            "value": value,
            "description": description,
            "dashboard-index": dashboard_index
        }
        r = post_response(url, self._get_headers(), payload, GameDayQuestsApiClient.post_image)
        return r.json()

    def delete_image(self, team_id, quest_id, key):
        """
        :param team_id: The team-id for the team for which you're deleting the image interaction for
        :param quest_id: The quest-id that the image interaction relates to
        :param key: The internal identifier for the image interaction
        """
        url = f"{self.api_base}/images/{team_id}/{quest_id}/{key}"
        r = delete_response(url, self._get_headers(), GameDayQuestsApiClient.delete_image)
        return r.json()

    def post_input(self, team_id, quest_id, key, label, description="", dashboard_index=""):
        """
        :param team_id: The team-id for the team for which you're creating the input field for
        :param quest_id: The quest-id that the input field relates to
        :param key: The internal identifier for the input field
        :param label: The label that applies to your field - usually a statement that tells the participant what
                      information to provide, or a question that tells the participant what answer to provide
        :param description: (Optional) Additional descriptive text that can appear as a tooltip, to provide the
                            participant with more information that what appears in the label.
        :param dashboard_index: (Optional) An index that allows you to set a display order for input fields. Fields with
                                lower order values are displayed above fields with higher order values. This
                                value must be an integer
        """
        url = f"{self.api_base}/inputs/{team_id}/{quest_id}/{key}"
        payload = {
            "label": label,
            "description": description
        }
        # The dashboard_index flag is NOT supported by the Event Engine, but is supported by the Quests Event UI.
        # In order to rmeain backwards compatible with content that was developed for the Event Engine, logic has been
        # written in to the back end that assumes a default dashboard-index if the value is not supplied - and it will
        # error if a null value is provided. Therefore this class should only pass on the parameter if it has been
        # supplied by the Quest. 
        if dashboard_index != "":
            payload['dashboard-index'] = dashboard_index
        r = post_response(url, self._get_headers(), payload, GameDayQuestsApiClient.post_input)
        return r.json()

    def get_input(self, team_id, quest_id, key):
        """
        :param team_id: The team-id for the team for which you're getting the input field for
        :param quest_id: The quest-id that the input field relates to
        :param key: The internal identifier for the input field

        Sample Response:
        {
            "team-id": "24eec976eca648eab61514b241032041",
            "quest-id": "7177f446-648c-4b38-b8f5-9928ac1b2045",
            "key": "test-field",
            "label": "Please enter your bank details.",
            "description": "Details are required so that Unicorn.Rentals can retrieve your donation from your account.",
            "value": "Account Number 879367294"
        }
        """
        url = f"{self.api_base}/inputs/{team_id}/{quest_id}/{key}"
        r = get_response(url, self._get_headers(), GameDayQuestsApiClient.get_input)
        return r.json()

    def delete_input(self, team_id, quest_id, key):
        """
        :param team_id: The team-id for the team for which you're deleting the input field for
        :param quest_id: The quest-id that the input field relates to
        :param key: The internal identifier for the input field
        """
        url = self.api_base + "/inputs/" + team_id + "/" + quest_id + "/" + key
        r = get_response(url, self._get_headers(), GameDayQuestsApiClient.delete_input)
        return r.json()

    def post_output(self, team_id, quest_id, key, label, value, dashboard_index, markdown=False, description=""):
        """
        :param team_id: The team-id for the team for which you're creating the output field for
        :param quest_id: The quest-id that the output field relates to
        :param key: The internal identifier for the output field
        :param label: The label that applies to your field - usually representing a heading that applies to
                      your output content
        :param value: The main content for your output, usually providing participants with information or
                      informing them of what to do. The value can contain plaintext or markdown-formatted content
                      (if markdown formatting is used, be sure to set the markdown flag to be true)
        :param dashboard_index: An index that allows you to set a display order for input fields. Fields with
                                lower order values are displayed above fields with higher order values. This
                                value must be an integer
        :param description: (Optional) Additional descriptive text that can appear as a tooltip, to provide the
                            participant with more information that what appears in the label
        :param markdown: (Optional) A flag that indicates if the output's value field contains markdown-formatted
                         content. Defaults to false If omitted or invalid.
        """
        url = f"{self.api_base}/outputs/{team_id}/{quest_id}/{key}"
        payload = {
            "label": label,
            "value": value,
            "description": description,
            "markdown": markdown,
            "dashboard-index": dashboard_index
        }
        r = post_response(url, self._get_headers(), payload, GameDayQuestsApiClient.post_output)
        return r.json()

    def delete_output(self, team_id, quest_id, key):
        """
        :param team_id: The team-id for the team for which you're deleting the output field for
        :param quest_id: The quest-id that the output field relates to
        :param key: The internal identifier for the output field
        """
        url = f"{self.api_base}/outputs/{team_id}/{quest_id}/{key}"
        r = delete_response(url, self._get_headers(), GameDayQuestsApiClient.delete_output)
        return r.json()

    def get_all_quests(self):
        """
        Sample Response:
        [
            {
                "quest-id": "7177f446-648c-4b38-b8f5-9928ac1b2045",
                "quest-dependencies": "",
                "quest-description": "This is a test, used to validate that the Quests API Orchestration works.",
                "quest-difficulty": "1",
                "quest-duration": "1",
                "quest-name": "Testing Quest",
                "quest-base-points": "1",
                "quest-central-status": "DEPLOYED",
                "quest-services": "[\"S3\", \"Step Functions\"]",
                "quest-enabled": true,
                "quest-use-case": "[\"Development\"]"
            },
            ...
        ]
        """
        url = f"{self.api_base}/quests"
        r = get_response(url, self._get_headers(), GameDayQuestsApiClient.get_all_quests)
        return r.json()

    def get_quest(self, quest_id):
        """
        :param quest_id: The quest-id of the Quest to retrieve
        Sample Response:
            {
                "quest-id": "7177f446-648c-4b38-b8f5-9928ac1b2045",
                "quest-dependencies": "",
                "quest-description": "This is a test, used to validate that the Quests API Orchestration works.",
                "quest-difficulty": "1",
                "quest-duration": "1",
                "quest-name": "Testing Quest",
                "quest-base-points": "1",
                "quest-central-status": "DEPLOYED",
                "quest-services": "[\"S3\", \"Step Functions\"]",
                "quest-enabled": true,
                "quest-use-case": "[\"Development\"]"
            }
        """
        url = f"{self.api_base}/quests/{quest_id}"
        r = get_response(url, self._get_headers(), GameDayQuestsApiClient.get_quest)
        return r.json()

    def get_hints_for_quest(self, quest_id):
        """
        :param quest_id: The quest_id to get all hints for
        Sample Response:
        [
            {
                "quest-id": "7177f446-648c-4b38-b8f5-9928ac1b2045",
                "key": "card",
                "label": "Where do I get the account details?",
                "description": "If you're stuck and need more info , activate this hint.",
                "value": "You can obtain your account details by looking on the back of your Unicorn.Rentals card."
                "dashboard-index": 100,
                "cost": 10,
                "enable-offset": 0,
                "disable-offset": 600,
                "automatic": true
            },
            ...
        ]
        """
        url = f"{self.api_base}/quests/{quest_id}/hints"
        r = get_response(url, self._get_headers(), GameDayQuestsApiClient.get_hints_for_quest)
        return r.json()

    def post_hints_for_quest(self,
                             quest_id,
                             key,
                             label,
                             description,
                             value,
                             dashboard_index,
                             cost,
                             enable_offset=0,
                             disable_offset=0,
                             automatic=True):
        """
        :param quest_id: The Quest ID to add this hint to
        :param key: A string that uniquely identifies this hint within the scope of the quest
        :param label: A string label that applies to your hint - usually representing a heading that applies to your
                      hint
        :param description: A string that is presented to participants to describe what this hint will reveal
        :param value: A string that is provided to participants once they reveal the hint; The main content for your
                      output, usually providing participants with information or informing them of what to do.
                      The value can contain plaintext or markdown-formatted content (if markdown formatting is used,
                      be sure to set the markdown flag to be true)
        :param dashboard_index: An index that allows you to set a display order for hints. Hints with lower order
                                values are displayed above hints with higher order values. This value must be an
                                integer and defaults to a value of 100 if not supplied"
        :param cost: A value that represents the percentage of base points for the quest that revealing this hint
                     will cost. This must be an integer between 0 and 100 and defaults to a value of 20 if not supplied
        :param enable_offset: A value that represents the number of seconds after a team starts working on a quest
                              before this hint is offered to that team (assuming that the automatic flag is set
                              to true). To display this hint to a team immediately after they start work on the quest,
                              set the enable-offset to 0. This value must be an integer and defaults to a value of 0
                               if not supplied
        :param disable_offset: A value that represents the number of seconds after a team starts working on a quest
                               before this hint expires (assuming that the automatic flag is set to true). To configure
                               the hint to never expire, set the disable-offset to 0. This value must be an integer,
                               must be greater than the enable-offset, and defaults to a value of 0 if not supplied
        :param automatic: A boolean field that determines if a team's hint state should be automatically updated.
                          If set to false, the initial status for each hint will be INACTIVE and code within the quest
                          will need to be developed to change the status for each team. If set to true, the initial
                          status for each hint will be HIDDEN - but will automatically transition to a SCHEDULED or
                          OFFERED state when the team starts the quest, depending on the value of the enable-offset
                          field (further state transitions occur depending on the configuration of the hint). This flag
                          defaults to a value of false if not submitted.
        """
        url = f"{self.api_base}/quests/{quest_id}/hints"
        payload = {"key": key,
                   "label": label,
                   "description": description,
                   "value": value,
                   "dashboard-index": dashboard_index,
                   "cost": cost,
                   "enable-offset": enable_offset,
                   "disable-offset": disable_offset,
                   "automatic": automatic
                   }
        r = post_response(url, self._get_headers(), payload, GameDayQuestsApiClient.post_hints_for_quest)
        return r.json()

    def patch_hint_for_quest(self,
                             quest_id,
                             key,
                             label,
                             description,
                             value,
                             dashboard_index,
                             cost,
                             enable_offset,
                             disable_offset,
                             automatic):
        """
        :param quest_id: The Quest ID to add this hint to
        :param key: A string that uniquely identifies this hint within the scope of the quest
        :param label: A string label that applies to your hint - usually representing a heading that applies to your
                      hint
        :param description: A string that is presented to participants to describe what this hint will reveal
        :param value: A string that is provided to participants once they reveal the hint; The main content for your
                      output, usually providing participants with information or informing them of what to do.
                      The value can contain plaintext or markdown-formatted content (if markdown formatting is used,
                      be sure to set the markdown flag to be true)
        :param dashboard_index: An index that allows you to set a display order for hints. Hints with lower order
                                values are displayed above hints with higher order values. This value must be an
                                integer and defaults to a value of 100 if not supplied"
        :param cost: A value that represents the percentage of base points for the quest that revealing this hint
                     will cost. This must be an integer between 0 and 100 and defaults to a value of 20 if not supplied
        :param enable_offset: A value that represents the number of seconds after a team starts working on a quest
                              before this hint is offered to that team (assuming that the automatic flag is set
                              to true). To display this hint to a team immediately after they start work on the quest,
                              set the enable-offset to 0. This value must be an integer and defaults to a value of 0
                               if not supplied
        :param disable_offset: A value that represents the number of seconds after a team starts working on a quest
                               before this hint expires (assuming that the automatic flag is set to true). To configure
                               the hint to never expire, set the disable-offset to 0. This value must be an integer,
                               must be greater than the enable-offset, and defaults to a value of 0 if not supplied
        :param automatic: A boolean field that determines if a team's hint state should be automatically updated.
                          If set to false, the initial status for each hint will be INACTIVE and code within the quest
                          will need to be developed to change the status for each team. If set to true, the initial
                          status for each hint will be HIDDEN - but will automatically transition to a SCHEDULED or
                          OFFERED state when the team starts the quest, depending on the value of the enable-offset
                          field (further state transitions occur depending on the configuration of the hint). This flag
                          defaults to a value of false if not submitted.
        """
        url = f"{self.api_base}/quests/{quest_id}/hints/{key}"
        payload = {
            "label": label,
            "description": description,
            "value": value,
            "dashboard-index": dashboard_index,
            "cost": cost,
            "enable-offset": enable_offset,
            "disable-offset": disable_offset,
            "automatic": automatic
        }
        r = patch_response(url, self._get_headers(), payload, GameDayQuestsApiClient.patch_hint_for_quest)
        return r.json()

    def get_quest_hints_for_team(self, quest_id, team_id):
        """
        :param quest_id: The ID of the Quest to retrieve hints from
        :param team_id: The ID of the Team to retreive hints from
        """
        url = f"{self.api_base}/teams/{team_id}/hints/{quest_id}"
        r = get_response(url, self._get_headers(), GameDayQuestsApiClient.get_quest_hints_for_team)
        return r.json()

    def get_quest_hint_for_team(self, quest_id, team_id, key):
        """
        :param quest_id: The ID of the Quest to retrieve hints from
        :param team_id: The ID of the Team to retrieve hints from
        :param key: The key identifying which hint to retrieve
        Sample Response:
        {
            "quest-id": "7177f446-648c-4b38-b8f5-9928ac1b2045",
            "key": "card",
            "label": "Where do I get the account details?",
            "description": "If you're stuck and need more info , activate this hint.",
            "value": "You can obtain your account details by looking on the back of your Unicorn.Rentals card."
            "dashboard-index": 100,
            "cost": 10,
            "enable-offset": 0,
            "disable-offset": 600,
            "automatic": true
        }
        """
        url = f"{self.api_base}/teams/{team_id}/hints/{quest_id}/{key}"
        r = get_response(url, self._get_headers(), GameDayQuestsApiClient.get_quest_hint_for_team)
        return r.json()

    def patch_quest_hint_for_team(self,
                             quest_id,
                             team_id,
                             key,
                             label,
                             description,
                             value,
                             dashboard_index,
                             cost,
                             enable_offset,
                             disable_offset,
                             automatic):
        """
        :param quest_id: The Quest ID to change this hint for
        :param team_id: The Team to change this hint for
        :param key: A string that uniquely identifies this hint within the scope of the quest
        :param label: A string label that applies to your hint - usually representing a heading that applies to your
                      hint
        :param description: A string that is presented to participants to describe what this hint will reveal
        :param value: A string that is provided to participants once they reveal the hint; The main content for your
                      output, usually providing participants with information or informing them of what to do.
                      The value can contain plaintext or markdown-formatted content (if markdown formatting is used,
                      be sure to set the markdown flag to be true)
        :param dashboard_index: An index that allows you to set a display order for hints. Hints with lower order
                                values are displayed above hints with higher order values. This value must be an
                                integer and defaults to a value of 100 if not supplied"
        :param cost: A value that represents the percentage of base points for the quest that revealing this hint
                     will cost. This must be an integer between 0 and 100 and defaults to a value of 20 if not supplied
        :param enable_offset: A value that represents the number of seconds after a team starts working on a quest
                              before this hint is offered to that team (assuming that the automatic flag is set
                              to true). To display this hint to a team immediately after they start work on the quest,
                              set the enable-offset to 0. This value must be an integer and defaults to a value of 0
                               if not supplied
        :param disable_offset: A value that represents the number of seconds after a team starts working on a quest
                               before this hint expires (assuming that the automatic flag is set to true). To configure
                               the hint to never expire, set the disable-offset to 0. This value must be an integer,
                               must be greater than the enable-offset, and defaults to a value of 0 if not supplied
        :param automatic: A boolean field that determines if a team's hint state should be automatically updated.
                          If set to false, the initial status for each hint will be INACTIVE and code within the quest
                          will need to be developed to change the status for each team. If set to true, the initial
                          status for each hint will be HIDDEN - but will automatically transition to a SCHEDULED or
                          OFFERED state when the team starts the quest, depending on the value of the enable-offset
                          field (further state transitions occur depending on the configuration of the hint). This flag
                          defaults to a value of false if not submitted.
        """
        url = f"{self.api_base}/teams/{team_id}/hints/{quest_id}/{key}"
        payload = {
            "label": label,
            "description": description,
            "value": value,
            "dashboard-index": dashboard_index,
            "cost": cost,
            "enable-offset": enable_offset,
            "disable-offset": disable_offset,
            "automatic": automatic
        }
        r = patch_response(url, self._get_headers(), payload, GameDayQuestsApiClient.patch_quest_hint_for_team)
        return r.json()

    def get_hint_for_quest(self, quest_id, key):
        """
        :param quest_id: The ID of the Quest to retrieve the hint from
        :param key: The key identifying which hint to retrieve
        Sample Response:
        {
            "quest-id": "7177f446-648c-4b38-b8f5-9928ac1b2045",
            "key": "card",
            "label": "Where do I get the account details?",
            "description": "If you're stuck and need more info , activate this hint.",
            "value": "You can obtain your account details by looking on the back of your Unicorn.Rentals card."
            "dashboard-index": 100,
            "cost": 10,
            "enable-offset": 0,
            "disable-offset": 600,
            "automatic": true
        }
        """
        url = f"{self.api_base}/quests/{quest_id}/hints/{key}"
        r = get_response(url, self._get_headers(), GameDayQuestsApiClient.get_hints_for_quest)
        return r.json()
    
    def patch_teams_hints_key(self, team_id, quest_id, key, enable_timestamp, disable_timestamp, status):
        """
        :param quest_id: The ID of the Quest to retrieve teams for
        :param team_id: The team ID for which the hint states will apply to
        :param key: The string that uniquely identifies this hint within the scope of the quest
        :param enable_timestamp:  A value that represents the timestamp (that is, the number of seconds 
                                since Unix Epoch) when a hint is offered for a team (or set to 0 if the hint is always offered). 
                                In general, you would only set this field to a timestamp if changing the status to HIDDEN or SCHEDULED, 
                                and you would only set this field to 0 if changing the status to HIDDEN or OFFERED since the enable-timestamp 
                                is irrelevant once a hint reaches the DISPLAYED or EXPIRED states. This value must be an integer and defaults 
        :param disable-offset:  A value that represents the timestamp (that is, the number of seconds since Unix Epoch) when a hint expires 
                                for a team (or set to 0 if the hint never expires). In general, you would only set this field to a timestamp 
                                or 0 if changing the status to HIDDEN, SCHEDULED or OFFERED since the disable-timestamp is irrelevant once a
                                hint reaches the DISPLAYED or EXPIRED states. This value must be an integer, must be greater than the 
                                enable-timestamp (the newly-supplied value if an enable-timestamp was supplied, otherwise the previously stored 
                                value will be used), and defaults to the previously stored value if not supplied;
                                to the previously stored value if not supplied;
        :param status: A string that represents the hint state, which must be one of the following values: INACTIVE, HIDDEN, OFFERED, SCHEDULED, DISPLAYED, EXPIRED or REVERSED.
        
        Sample Response:
        {    
            "team-id": "24eec976eca648eab61514b241032041"
            "quest-id": "7177f446-648c-4b38-b8f5-9928ac1b2045",
            "key": "lost",
            "label": "Have you lost your Unicorn.Rentals debit card?",
            "description": "If you've lost your Unicorn.Rentals debit card and no longer have access to your account details, activate this hint.",
            "value": "You can obtain your account details by going looking on the back of your Unicorn.Rentals debit card. You'll need to supply all of the digits for your account number including any leading zeroes."
            "dashboard-index": 100,
            "cost": 80,
            "quest-start-timestamp": 1623818357
            "enable-timestamp": 0,
            "disable-timestamp": 0,
            "status": "REVERSED"
        }
        """
        url = f"{self.api_base}/quests/{quest_id}/hints/{key}"
        payload = {
            "enable-timestamp": enable_timestamp,
            "disable-timestamp": disable_timestamp,
            "status": status 
        }
        r = patch_response(url, self._get_headers(), payload, GameDayQuestsApiClient.patch_teams_hints_key)
        return r.json()

    def get_teams_for_quest(self, quest_id):
        """
        :param quest_id: The ID of the Quest to retrieve teams for
        :returns: list of teams that have engaged with the given quest
        Sample Response:
        [
            {
                "quest-team-enable-stack-id": "",
                "quest-id": "7177f446-648c-4b38-b8f5-9928ac1b2045",
                "quest-team-enable-stack-outputs": "[]",
                "quest-state": "IN_PROGRESS",
                "quest-complete-time": "0",
                "quest-start-time": "0",
                "team-id": "24eec976eca648eab61514b241032041"
            },
            ...
        ]
        """
        url = f"{self.api_base}/quests/{quest_id}/teams"
        r = get_response(url, self._get_headers(), GameDayQuestsApiClient.get_teams_for_quest)
        return r.json()

    def get_all_teams(self):
        """
        :returns: All teams for this event
        Sample Response:
        [
            {
                "team-name-approved": true,
                "team-role-arn": "arn:aws:iam::<account-id>:role/TeamRole",
                "ops-role-arn": "arn:aws:iam::<account-id>:role/OpsRole",
                "team-name": "A unicorn poked me in the eye!",
                "ssh-keypair-fingerprint": "a7:78:7a:b9:68:15:fb:8c:c6:7d:95:38:21:d1:65:36:86:2c:5c:70",
                "team-id": "35ffda87fdb759fbc72625c352143152",
                "ssh-keypair-name": "ee-default-keypair",
                "account-id": "<account-id>"
            },
            ...
        ]
        """
        url = f"{self.api_base}/teams"
        r = get_response(url, self._get_headers(), GameDayQuestsApiClient.get_all_teams)
        return r.json()

    def get_team(self, team_id):
        """
        :param team_id: The ID of the team to get info for
        Sample Response:
        {
            "team-name-approved": true,
            "team-role-arn": "arn:aws:iam::<account-id>:role/TeamRole",
            "ops-role-arn": "arn:aws:iam::<account-id>:role/OpsRole",
            "team-name": "A unicorn poked me in the eye!",
            "ssh-keypair-fingerprint": "a7:78:7a:b9:68:15:fb:8c:c6:7d:95:38:21:d1:65:36:86:2c:5c:70",
            "team-id": "35ffda87fdb759fbc72625c352143152",
            "ssh-keypair-name": "ee-default-keypair",
            "account-id": "<account-id>"
        }
        """
        url = f"{self.api_base}/teams/{team_id}"
        r = get_response(url, self._get_headers(), GameDayQuestsApiClient.get_team)
        return r.json()

    def get_quests_for_team(self, team_id):
        """
        :param team_id: The ID of the team to retrieve Quests for
        :returns: All quests engaged with by the given team
        Sample Response:
        [
            {
                "quest-team-enable-stack-id": "",
                "quest-id": "7177f446-648c-4b38-b8f5-9928ac1b2045",
                "quest-team-enable-stack-outputs": "[]",
                "quest-state": "AVAILABLE",
                "quest-complete-time": "0",
                "quest-start-time": "0",
                "team-id": "24eec976eca648eab61514b241032041"
            },
            ...
        ]
        """
        url = f"{self.api_base}/teams/{team_id}/quests"
        r = get_response(url, self._get_headers(), GameDayQuestsApiClient.get_quests_for_team)
        return r.json()

    def get_quest_for_team(self, team_id, quest_id):
        """
        :param team_id: The ID of the team to retrieve Quests for
        :param quest_id: The ID of the Quest to retrieve
        :returns: Quest data for the given team
        Sample Response:
        {
            "quest-team-enable-stack-id": "",
            "quest-id": "7177f446-648c-4b38-b8f5-9928ac1b2045",
            "quest-team-enable-stack-outputs": "[]",
            "quest-state": "AVAILABLE",
            "quest-complete-time": "0",
            "quest-start-time": "0",
            "team-id": "24eec976eca648eab61514b241032041"
        }
        """
        all_quests_for_team = self.get_quests_for_team(team_id)
        for quest in all_quests_for_team:
            if quest['quest-id'] == quest_id:
                return quest
        return None

    def post_quest_complete(self, team_id, quest_id, weighting):
        """
        :param team_id: The team to mark as having completed the quest
        :param quest_id: The quest to mark complete for this team
        :param weighting: The (integer) percentage of the quest point total to award this team
        """
        url = f"{self.api_base}/teams/{team_id}/complete/{quest_id}"
        payload = {
            "score-weighting": int(weighting)
        }
        r = post_response(url, self._get_headers(), payload, GameDayQuestsApiClient.post_quest_complete)
        return r.json()

    def post_quest_start(self, team_id, quest_id):
        """
        :param team_id: The ID of the team to start the Quest for
        :param quest_id: The ID of the quest to start for this team
        """
        url = f"{self.api_base}/teams/{team_id}/start/{quest_id}"
        r = post_response(url, self._get_headers(), {}, GameDayQuestsApiClient.post_quest_start)
        return r.json()

    def post_quest_interim_score(self, team_id, quest_id, score_weighting):
        """
        :param team_id: The team to mark as having completed the quest
        :param quest_id: The quest to mark complete for this team
        :param score_weighting: The (integer) percentage of the quest point total to award this team
        """
        url = f"{self.api_base}/teams/{team_id}/score/{quest_id}"
        payload = {
            'score-weighting': int(score_weighting)
        }
        r = post_response(url, self._get_headers(), payload, GameDayQuestsApiClient.post_quest_interim_score)
        return r.json()

    def _get_headers(self):
        return {
            'Authorization': f'Bearer {self.api_token}',
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        }
