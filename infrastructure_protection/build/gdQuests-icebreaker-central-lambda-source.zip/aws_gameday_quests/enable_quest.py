import argparse
import json
import boto3
import time
import os
from argparse import RawTextHelpFormatter

try:
    PROFILE = os.environ['AWS_GAMEDAY_PROFILE']
    boto3_session = boto3.Session(profile_name=PROFILE)
except Exception as e:
    boto3_session = boto3.Session()


lambda_client = boto3_session.client('lambda')
dynamo_client = boto3_session.client('dynamodb')


def wait_for_quest(quest_id: str, wait_tolerance: int, abort_status='ERRORED'):
    available = False
    start_time = time.perf_counter()

    while not available:
        ddb_response = dynamo_client.get_item(
            TableName='gdQuestsApi-Quests',
            Key={
                'quest-id': {'S': quest_id}
            }
        )
        quest_data = ddb_response.get('Item')
        if quest_data is None:
            raise Exception('Quest does not exist in gdQuestsApi-Quests ' +
                            'table. Unable to recover. Check your ' +
                            'dev-quest-data.json file. You may need to ' +
                            'redeploy the QDK.')
        available = quest_data['quest-central-status']["S"] == 'DEPLOYED'
        if not available:
            abort = quest_data['quest-central-status']["S"] == abort_status
            if abort:
                raise Exception(f"Quest encountered status {abort_status}, aborting. " +
                      f"Review CloudWatch logs to diagnose")

            print("Quest not available, status: " +
                  quest_data['quest-central-status']['S'] +
                  ", waiting 20 seconds for step function")
            if time.perf_counter() - start_time > (wait_tolerance * 60):
                raise Exception(f'Quest taking >{wait_tolerance} minutes to ' +
                                'deploy. Check Quests StepFunctions/' +
                                'CloudWatch Logs.')
            time.sleep(20)


def provision_quest(quest_id: str, wait_tolerance: int):
    response = lambda_client.invoke(
        FunctionName='gdQuestsDev-EnableQuest',
        InvocationType='RequestResponse',
        LogType='Tail',
        Payload=json.dumps({'quest-id': quest_id, 'deploy': True})
    )
    wait_for_quest(quest_id, wait_tolerance)

    return response


def wait_for_team_quest(quest_id: str, team_id: str, wait_tolerance: int,
                        status='AVAILABLE', abort_status='ERRORED'):
    ready = False
    start_time = time.perf_counter()

    while not ready:
        ddb_response = dynamo_client.get_item(
            TableName='gdQuestsApi-QuestStates',
            Key={
                'quest-id': {'S': quest_id},
                'team-id': {'S': team_id}
            }
        )
        team_quest_data = ddb_response.get('Item')
        if team_quest_data is None:
            raise Exception(
                'No entry found for team/quest pair in gdQuestsApi-QuestStates'
            )
        ready = team_quest_data['quest-state']['S'] == status
        if not ready:
            abort = team_quest_data['quest-state']["S"] == abort_status
            if abort:
                raise Exception(f"Encountered status {abort_status}, aborting. " +
                      f"Review CloudWatch logs to diagnose")

            print("Quest not ready for team. Status: " +
                  team_quest_data['quest-state']['S'] +
                  ", expecting: " + status +
                  " waiting 20s before retry."
            )
            if time.perf_counter() - start_time > (wait_tolerance * 60):
                raise Exception(f'Quest taking >{wait_tolerance} minutes to ' +
                                'initialize. Check Quests StepFunctions/' +
                                'CloudWatch Logs.')
            time.sleep(20)


def activate_quest(quest_id: str, team_id: str, wait_tolerance: int):
    wait_for_quest(quest_id, wait_tolerance)
    wait_for_team_quest(quest_id, team_id, wait_tolerance, status='AVAILABLE')

    response = lambda_client.invoke(
        FunctionName='gdQuestsApi-PostQuestStart',
        InvocationType='RequestResponse',
        LogType='Tail',
        Payload=json.dumps({'team-id': team_id, 'quest-id': quest_id})
    )
    wait_for_team_quest(quest_id, team_id, wait_tolerance, status='IN_PROGRESS')

    return response


def main(argv=None):
    parser = argparse.ArgumentParser(description="""
        Enable the provided quest-id by invoking the gdQuestsDev-EnableQuest
        and/or gdQuestsApi-postQuestStart Lambda Functions deployed as part 
        of the QDK. The process flow is to enable a quest globally, and then 
        individually for teams. Ensure that your quest assets have been
        packaged and deployed prior to enabling it.

        This helper script will interact with the default AWS profile 
        configured in your environment.
    """, formatter_class=RawTextHelpFormatter)
    parser.add_argument(
        "--quest-id", help="Quest ID to enable in your QDK environment",
        required=True
    )
    parser.add_argument(
        "--team-id",
        help="The Team ID to enable the given Quest ID for in your QDK" +
             "environment. The Question should be enabled globally first. " +
             "Team IDs are dependent on your QDK environment, however the " +
             "default placeholder Team IDs deployed to the " +
             "gdQuestsApi-MockTeams DynamoDb table is: " +
             "24eec976eca648eab61514b241032041"
    )
    parser.add_argument(
        "--wait-tolerance",
        help="Minutes to wait for deployment actions to occur",
        type=int,
        default=5)

    params = vars(parser.parse_args(argv))

    quest_id = params['quest_id']
    team_id = params['team_id']
    wait_tolerance = params.get('wait_tolerance')

    # Assumes quest_id is not None due to argparse requirements. Error will be
    # passed through from the Lambda side if this assumption is false (e.g.
    # an unforseen external caller)

    ddb_response = dynamo_client.get_item(
        TableName='gdQuestsApi-Quests',
        Key={
            'quest-id': {'S': quest_id}
        }
    )
    quest_data = ddb_response.get('Item')

    if quest_data is None:
        print('Quest does not exist in gdQuestsApi-Quests table. Check your ' +
              'dev-quest-data.json file. You may need to redeploy the QDK.')
        return

    quest_enabled = quest_data['quest-central-status']["S"] == 'DEPLOYED' \
        and quest_data['quest-enabled']["BOOL"]

    if team_id is None:
        if quest_enabled:
            print(f"Quest {quest_id} is already enabled.")
            return

        response = provision_quest(quest_id, wait_tolerance)
    else:
        if not quest_enabled:
            print(f"Quest {quest_id} is not yet enabled. Enabling globally "
                  f"before enabling for team {team_id}")
            response = provision_quest(quest_id, wait_tolerance)
            print(response['Payload'].read())

        response = activate_quest(quest_id, team_id, wait_tolerance)

    print(response['Payload'].read())


if __name__ == "__main__":
    main()
