import argparse
import json
import boto3
import os
from argparse import RawTextHelpFormatter
from .gdQuestsApi import GameDayQuestsApiClient

quests_client = GameDayQuestsApiClient()

QUEST_MOCK_INPUTS_TABLE = "gdQuestsApi-Inputs"

try:
    PROFILE = os.environ['AWS_GAMEDAY_PROFILE']
    boto3_session = boto3.Session(profile_name=PROFILE)
except Exception as e:
    boto3_session = boto3.Session()


def main(argv=None):
    parser = argparse.ArgumentParser(description="""
        Simulate a mock event for testing a Quest
    """, formatter_class=RawTextHelpFormatter)
    parser.add_argument(
        "--event-type",
        help="Delete all quest stacks and delete the QDK " +
             "CloudFormation stack, if concurrent with -deploy, " +
             "this will occur first",
        choices=["INPUT_UPDATED", "IN_PROGRESS", "STOPPED"],
        required=True
    )
    parser.add_argument(
        "-quick-create",
        help="If using event-type INPUT_UPDATED and the input doesn't exist yet, " +
             "create with this. This is generally an anti-pattern outside of unit testing " +
             "the QDK. Your quest should be creating the input. Lifecycle events like QUEST_STOPPED "
             "and QUEST_IN_PROGRESS should have QUEST_ removed to represent operator action at "
             "the event level.",
        action='store_true',
        default=False
    )
    parser.add_argument(
        "--quest-id", help="Quest to send the event to",
        required=True
    )
    parser.add_argument(
        "--team-id",
        help="The Team ID to send the event to. " +
             "Team IDs are dependent on your QDK environment, however the " +
             "default placeholder Team IDs deployed to the " +
             "gdQuestsApi-MockTeams DynamoDb table is: " +
             "24eec976eca648eab61514b241032041"
    )
    parser.add_argument("--input-key",
                        type=str,
                        help="If using event type INPUT_UPDATED, the key identifying this input")
    parser.add_argument("--input-value",
                        type=str,
                        help="If using event type INPUT_UPDATED, the mock value")
    params = vars(parser.parse_args(argv))

    event_type = params.get('event_type')
    quest_id = params.get('quest_id')
    team_id = params.get('team_id')
    input_key = params.get('input_key')
    input_value = params.get('input_value')
    quick_create = params.get('quick_create')

    if event_type == "INPUT_UPDATED":
        if quick_create:
            quests_client.post_input(
                team_id=team_id,
                quest_id=quest_id,
                key=input_key,
                label=input_key + " label",
                description=input_key + " description")

        # Write the input event to the mock inputs table, if it exists
        ddb_client = boto3_session.resource("dynamodb")
        mock_inputs_table = ddb_client.Table(QUEST_MOCK_INPUTS_TABLE)
        current_input_result = mock_inputs_table.get_item(
            Key={
                'key': quest_id + "_" + input_key,
                'team-id': team_id
            },
            ConsistentRead=False
        )
        if current_input_result['Item'] is None:
            print("Attempting to simulate team input for a non-existing input. Ensure your quest " +
                  "has created this input via quests_client.post_input()")
            return
        current_input_result['Item']['value'] = input_value
        print(f"Item to write: {current_input_result}")
        write_input_result = mock_inputs_table.put_item(Item=current_input_result['Item'])
        print(f"Result writing to {QUEST_MOCK_INPUTS_TABLE}: {write_input_result}")

        # Find the SnsMockTopic
        sns_client = boto3_session.client("sns")
        sns_topics_result = sns_client.list_topics()
        more_to_process = True
        mock_sns_topic = None
        while more_to_process:
            for topic in sns_topics_result['Topics']:
                if "-SnsMockTopic-" in topic['TopicArn']:
                    if mock_sns_topic is None:
                        mock_sns_topic = topic['TopicArn']
                    else:
                        print(f"Unable to differentiate appropriate SNS topics: {mock_sns_topic}, "
                              f"{topic['TopicArn']}. Aborting.")
                        return
            more_to_process = "NextToken" in sns_topics_result.keys()
        if mock_sns_topic is None:
            print("Unable to find SnsMockTopic for the QDK, ensure your stack is successfully delployed.")
            return

        # Write to the mock SNS topic
        quest = quests_client.get_quest_for_team(team_id=team_id, quest_id=quest_id)
        sns_response = sns_client.publish(
            TopicArn=mock_sns_topic,
            Message=json.dumps(
                {
                    "event": "eventengine:INPUT_UPDATED",
                    # "quest-id": quest_id,
                    # "quest-state": quest['quest-state'],
                    "module-id": "Null",  # This value comes from the dev-central-cfn.yaml
                    "team-id": team_id,
                    "key": f"{quest_id}_{input_key}",
                    "label": current_input_result['Item']['label'],
                    "description": current_input_result['Item']['description'],
                    "new-value": current_input_result['Item']['value'],
                }
            ),
            MessageAttributes={
                "event": {"DataType": "String", "StringValue": "eventengine:INPUT_UPDATED"},
                "quest-id": {"DataType": "String", "StringValue": quest_id},
                "team-id": {"DataType": "String", "StringValue": team_id}
            }
        )
        print(f"Publish response from SNS:{sns_response}")

    elif event_type == "STOPPED" or event_type == "IN_PROGRESS":
        lambda_client = boto3_session.client("lambda")
        mock_event_lambda_response = lambda_client.invoke(
            FunctionName='gdQuestsDev-MockEvents',
            InvocationType='RequestResponse',
            LogType='Tail',
            Payload=json.dumps({'status': event_type})
        )
        print(mock_event_lambda_response)
    else:
        print(f"Unknown event type {event_type} provided, nothing to do.")
        return
    print("Mock event injection complete.")


if __name__ == "__main__":
    main()
