import argparse
import json
import boto3
import botocore
import time
import uuid
import os
from argparse import RawTextHelpFormatter
from .gdQuestsApi import GameDayQuestsApiClient
import multiprocessing

try:
    PROFILE = os.environ['AWS_GAMEDAY_PROFILE']
    boto3_session = boto3.Session(profile_name=PROFILE)
except Exception as e:
    boto3_session = boto3.Session()


cfn_client = boto3_session.client("cloudformation")
s3_client = boto3_session.client("s3")
QDK_FINGERPRINT_PARAMS = [
    'EventUILambdaSourceKey',
    'EventUIWebsiteSourceKey',
    'gdQuestsEEAssetsBucketPrefix',
    'gdQuestsEEAssetsKeyPrefix',
    'devDeploymentArtifactSource',
    'devAssetsBucket',
    'gdQuestsLambdaSourceKey',
    'devAssetsKeyPrefix',
    'devQuestsData'
]
WAIT_INTERVAL = 20


def undeploy_stack(stack_name, wait_tolerance=30):
    print(f"Deleting {stack_name}...")
    delete_token = f"qdk-delete-{uuid.uuid4()}"
    cfn_response = cfn_client.delete_stack(StackName=stack_name, ClientRequestToken=delete_token)
    delete_waiter = cfn_client.get_waiter('stack_delete_complete')
    max_wait_seconds = wait_tolerance * 60
    max_attempts = int(max_wait_seconds / 20)
    delete_waiter.wait(
        StackName=stack_name,
        WaiterConfig={
            'Delay': WAIT_INTERVAL,
            'MaxAttempts': max_attempts
        }
    )
    print(f"Waiter returned for StackDeleteComplete of {stack_name}, verifying deletion")
    try:
        cfn_confirm_response = cfn_client.describe_stacks(StackName=stack_name)
    except botocore.exceptions.ClientError:
        cfn_confirm_response = {'Stacks': []}

    if len(cfn_confirm_response['Stacks']) != 0:
        print("Stack still exists, failing. Please review via the CloudFormation console.")
        raise Exception(
            f"Stack {stack_name} not deleted successfully: {json.dumps(cfn_confirm_response)}"
        )
    print("Deletion confirmed.")


def undeploy_quests(quests_client, wait_tolerance=30):
    quests = quests_client.get_all_quests()
    possible_stacks = []
    for quest in quests:
        possible_stacks.append(f"gdQuests-{quest['quest-id']}-Enable")
        possible_stacks.append(f"gdQuests-{quest['quest-id']}-Central")
        possible_stacks.append(f"gdQuests-{quest['quest-id']}-Activate")
    cfn_response = cfn_client.describe_stacks()
    stacks_to_delete = []
    for stack in cfn_response['Stacks']:
        if stack['StackName'] in possible_stacks:
            stacks_to_delete.append((stack['StackName'], wait_tolerance))

    print(f"{len(stacks_to_delete)} Quest stacks found to delete, launching deleter pool")
    pool = multiprocessing.Pool(5)
    pool.starmap(undeploy_stack, stacks_to_delete)
    pool.close()
    pool.join()
    print("Deletes complete")


def undeploy_qdk(wait_tolerance=30):
    # Find the stack matching the QDK fingerprint and delete it
    cfn_response = cfn_client.describe_stacks()
    for stack in cfn_response['Stacks']:
        if 'Parameters' not in stack.keys():
            continue
        stack_params = [s['ParameterKey'] for s in stack['Parameters']]
        if sorted(stack_params) == sorted(QDK_FINGERPRINT_PARAMS):
            # We found our stack
            print(f"Found stack {stack['StackName']} matching the QDK fingerprint")
            undeploy_stack(stack['StackName'], wait_tolerance)
            return
    print("QDK Stack not found, nothing to do")


def deploy_qdk(
        s3_target: str,
        template_file_path: str,
        dev_assets_bucket: str,
        dev_assets_key_prefix: str,
        gd_quests_ee_assets_bucket_prefix: str,
        wait_tolerance=30):
    bucket_name = s3_target.split('/')[0]
    object_name = s3_target[len(bucket_name) + 1:]
    object_name += "dev-central-cfn.yaml"
    template_url = f"https://{bucket_name}.s3.amazonaws.com/{object_name}"
    print(f"Uploading CloudFormation template to {template_url }")
    s3_client.upload_file(template_file_path, bucket_name, object_name)
    print("Upload complete")
    s3_signing_response = s3_client.generate_presigned_url('get_object',
                                                           Params={
                                                               'Bucket': bucket_name,
                                                               'Key': object_name
                                                           },
                                                           ExpiresIn=60)
    stack_name = f"gameday-qdk-{time.strftime('%Y-%m-%d')}"
    print(f"Creating AWS GameDay QDK stack {stack_name}")
    cfn_response = cfn_client.create_stack(
        StackName=stack_name,
        TemplateURL=s3_signing_response,
        Capabilities=['CAPABILITY_NAMED_IAM'],
        Parameters=[
            {'ParameterKey': 'devAssetsBucket', 'ParameterValue': dev_assets_bucket},
            {'ParameterKey': 'devAssetsKeyPrefix', 'ParameterValue': dev_assets_key_prefix},
            {'ParameterKey': 'gdQuestsEEAssetsBucketPrefix', 'ParameterValue': gd_quests_ee_assets_bucket_prefix},
            {'ParameterKey': 'devDeploymentArtifactSource', 'ParameterValue': 'Development'}
        ]
    )
    print(f"CreateStack response {json.dumps(cfn_response)}. Waiting for completion")
    create_waiter = cfn_client.get_waiter('stack_create_complete')
    max_wait_seconds = wait_tolerance * 60
    max_attempts = int(max_wait_seconds / 20)
    create_waiter.wait(
        StackName=stack_name,
        WaiterConfig={
            'Delay': WAIT_INTERVAL,
            'MaxAttempts': max_attempts
        }
    )
    print("Verifying CREATE_COMPLETE")
    cfn_confirm_response = cfn_client.describe_stacks(
        StackName=stack_name
    )
    if (len(cfn_confirm_response['Stacks']) == 0 or
            cfn_confirm_response['Stacks'][0]['StackStatus'] != "CREATE_COMPLETE"):
        print("Stack creation failed or didn't finish in specified time. Please review via the CloudFormation console.")
        raise Exception(f"Stack {stack_name} not created successfully: {json.dumps(cfn_confirm_response)}")
    print("Success.")
    return cfn_confirm_response['Stacks'][0]


def main(argv=None):
    parser = argparse.ArgumentParser(description="""
        Deploy or undeploy the QDK to a test AWS account. It is assumed
        that an AWS profile with appropriate permissions is already 
        configured.
    """, formatter_class=RawTextHelpFormatter)
    parser.add_argument(
        "--s3-target",
        help="S3 bucket+prefix (e.g. mybucket/) to upload the QDK template to, " +
             "as the template size is greater than the inline limit",
    )
    parser.add_argument(
        "--template-file",
        help="Path, including file name, to dev-central-cfn.yaml",
    )
    parser.add_argument(
        "-undeploy",
        help="Delete all quest stacks and delete the QDK " +
             "CloudFormation stack. If concurrent with -deploy, " +
             "this will occur first.",
        action='store_true',
        default=False)
    parser.add_argument(
        "-deploy",
        help="Deploy the QDK CloudFormation stack. If concurrent " +
             "with -undeploy, this will occur second.",
        action='store_true',
        default=False)
    parser.add_argument(
        "--dev-assets-bucket",
        help="he name of the S3 Bucket that contains all development artifacts. " +
             "Objects in this bucket must be able to be read by CloudFormation whilst deploying this template"
    )
    parser.add_argument(
        "--dev-assets-key-prefix",
        help="The S3 key prefix used to locate all development artifacts within the devAssetsBucket",
        default=""
    )
    parser.add_argument(
        "--gd-quests-ee-assets-bucket-prefix",
        help="The S3 Bucket name prefix containing deployment artifacts for the AWS GameDay Quests " +
             "Development Kit - Do not modify, for internal use only.",
        default="ee-assets-prod-"
    )
    parser.add_argument(
        "--wait-tolerance",
        help="Minutes to wait for deployment actions to occur",
        type=int,
        default=30)

    params = vars(parser.parse_args(argv))

    wait_tolerance = params.get('wait_tolerance')
    s3_target = params.get('s3_target')
    template_file = params.get('template_file')
    undeploy = params.get('undeploy')
    deploy = params.get('deploy')
    dev_assets_bucket = params.get('dev_assets_bucket')
    dev_assets_key_prefix = params.get('dev_assets_key_prefix')
    gd_quests_ee_assets_bucket_prefix = params.get('gd_quests_ee_assets_bucket_prefix')

    if undeploy:
        quests_client = None
        try:
            quests_client = GameDayQuestsApiClient()
        except Exception as e:
            print(f"Unable to create GameDay Quests API Client due to error: {e}. Skipping Quest deletion attempt.")
        if quests_client is not None:
            # Undeploy Quests first to avoid dependencies or race conditions for dependent IAM roles
            print("Undeploying existing Quests and QDK")
            undeploy_quests(quests_client=quests_client, wait_tolerance=wait_tolerance)
        undeploy_qdk(wait_tolerance=wait_tolerance)
    if deploy:
        print("Deploying QDK")
        if s3_target is None or not s3_target.endswith('/'):
            print(f"Unable to deploy. s3-target: {s3_target} must include a valid bucket name and prefix."
                  f"(minimally /), e.g. mybucket/)")
            return
        if dev_assets_bucket in [None, ""]:
            print("Unable to deploy, dev_assets_bucket is required if deploying.")
            return
        if template_file in [None, ""]:
            print("Unable to deploy, template_file is required if deploying.")
            return
        qdk_stack = deploy_qdk(
            s3_target=s3_target,
            template_file_path=template_file,
            wait_tolerance=wait_tolerance,
            dev_assets_bucket=dev_assets_bucket,
            dev_assets_key_prefix=dev_assets_key_prefix,
            gd_quests_ee_assets_bucket_prefix=gd_quests_ee_assets_bucket_prefix
        )
        event_ui_output = None
        for output in qdk_stack['Outputs']:
            if output['OutputKey'] == "EventUIURL":
                event_ui_output = output
                break
        if event_ui_output is None:
            print("EventUI output not found!")
        else:
            print(f"Event UI Dashboard endpoint: {event_ui_output['OutputValue']}")
        print("Generating EventUI credentials.")
        lambda_client = boto3_session.client("lambda")
        cognito_lambda_response = lambda_client.invoke(
            FunctionName='gdQuests-EventUI-TeamCredentials',
            InvocationType='RequestResponse',
            LogType='Tail',
            Payload=json.dumps({'testing': True})
        )
        print(str(cognito_lambda_response['Payload'].read()))


if __name__ == "__main__":
    main()
